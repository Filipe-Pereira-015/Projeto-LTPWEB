package com.example.myapplication;

import android.app.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import android.view.View;
import android.widget.*;
import android.os.*;
import android.content.Intent;

public class MainActivity extends Activity {

    CheckBox chkArroz, chkFeijao,chkCarne,chkLeite;
    Button btComprar;

    TextView qtdArroz, qtdFeijao, qtdLeite, qtdCarne;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkArroz = (CheckBox) findViewById(R.id.chkArroz);
        chkFeijao = (CheckBox) findViewById(R.id.chkFeijao);
        chkCarne = (CheckBox) findViewById(R.id.chkCarne);
        chkLeite = (CheckBox) findViewById(R.id.chkLeite);

        qtdFeijao = (TextView) findViewById(R.id.chkFeijao);
        qtdArroz = (TextView) findViewById(R.id.qtdArroz);
        qtdCarne = (TextView) findViewById(R.id.qtdCarne);
        qtdLeite = (TextView) findViewById(R.id.qtdLeite);

        btComprar = (Button) findViewById(R.id.button);

        btComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialogo1 = new AlertDialog.Builder(MainActivity.this);
                dialogo1.setTitle("Forma de Pagamento");
                String[] pagamento = {"PIX", "Débito", "Crédito", "Boleto"};
                dialogo1.setSingleChoiceItems(pagamento, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        double total_compra = 0;

                        if (chkArroz.isChecked()){
                            int arroz = Integer.parseInt(qtdArroz.getText().toString());
                            total_compra += 10 * arroz;
                        }
                        if (chkCarne.isChecked()){
                            int carne = Integer.parseInt(qtdCarne.getText().toString());
                            total_compra += 20.99 * carne;
                        }
                        if (chkFeijao.isChecked()){
                            int feijao = Integer.parseInt(qtdFeijao.getText().toString());
                            total_compra += 8 * feijao;
                        }
                        if (chkLeite.isChecked()){
                            int leite = Integer.parseInt(qtdLeite.getText().toString());
                            total_compra += 2.99 * leite;
                        }

                        AlertDialog.Builder dialogo2 = new AlertDialog.Builder(MainActivity.this);

                        dialogo2.setTitle("Total da Compra");
                        dialogo2.setMessage("Total da compra é R$ " + total_compra);
                        dialogo2.setNeutralButton("ok", null);
                        dialogo2.show();
                    }
                });
                dialogo1.show();
            }

        });

    }

}