package com.projeto.sistemadecompras;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.app.*;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    CheckBox chkarroz, chkleite, chkcarne, chkfeijao;

    Button bttotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkarroz = (CheckBox) findViewById(R.id.chkarroz);
        chkleite = (CheckBox) findViewById(R.id.chkleite);
        chkcarne = (CheckBox) findViewById(R.id.chkcarne);
        chkfeijao = (CheckBox) findViewById(R.id.chkfeijao);
        Button bttotal = (Button) findViewById(R.id.bttotal);


        bttotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                AlertDialog.Builder dialogo1 = new AlertDialog.Builder( MainActivity.this);
                String[] pagamento = {"PIX", "CREDITO", "DEBITO", "BOLETO"};
                dialogo1.setSingleChoiceItems(pagamento, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        double total = 0;
                        if (chkarroz.isChecked())
                            total += 2.69;
                        if (chkleite.isChecked())
                            total += 5.00;
                        if (chkcarne.isChecked())
                            total += 9.7;
                        if (chkfeijao.isChecked())
                            total += 2.30;
                        AlertDialog.Builder dialogo = new AlertDialog.Builder(
                                MainActivity.this);
                        dialogo.setTitle("Aviso");
                        dialogo.setMessage("Valor total da Compra : " +(total));
                        dialogo.setNeutralButton("OK", null);
                        dialogo.show();
                    }
                });
                dialogo1.show();

            }
        });
    }
}